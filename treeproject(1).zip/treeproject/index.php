<!doctype html>
<html lang="en">
  <head>
     <link rel="stylesheet" href="style.css">

   
	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">




    
     <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />

      <link rel="stylesheet" href="style.css">


    <script src="https://kit.fontawesome.com/d9a8de9e4b.js" crossorigin="anonymous"></script>
    <link rel="icon" href="favicon.jpg" type="image/jpg">
      
    <title>ecommerce</title>

    <style>

	 .navbar-nav a
              {
                font-family: Arial,Helvetica,sans-serif;
                font-size: 18px;
              }

              .navbar-light .navbar-brand
              {
                color:#fff;
                font-size: 25px;
                font-weight: bold;
                letter-spacing: 2px;
              }

              .navbar
              {
                background: rgb(34,139,34);
              }

               .navbar-light .navbar-nav .active > .nav-link, .navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .show>.nav-link 
               {
                  color: #E3791A;
               }
               .navbar-light .navbar-nav .nav-link
               {
                color: #E3791A;;
               }

               .navbar-nav
               {
                text-align: center;
               }
               .navbar-link
               {
                padding:.2rem 1rem;
               }

              .navbar-light .navbar-nav .nav-link:focus,.navbar-light .navbar-nav .nav-link:hover
               {
                color: #CBD7D0 !important;
               }
              
              .w-100
              {
                height:80vh;
              }

              @media only screen and (max-width: 767px)
              {
                .navbar-nav.ml-auto
                {
                  background: rgba(0,0,0,0.5);
                }
                .navbar-toggler
                {
                  padding:1px 5px;
                  font-size: 18px;
                  line-height: 0.3;
                  background: #fff;
                }
              }

            
                  .icons
                  {
                    
                    position: fixed;
                    top:30%;
                    left:0%;
                    width:200px;
                    display:flex;
                    flex-direction: column;
                  }


                  .icons a
                  {
                    text-decoration: none;
                    
                    padding:10px;
                    font-size: 22px;
                    font-family: 'Oswald', sans-serif;
                    margin:2px;
                    text-align: right;
                    border-radius: 0px 50px 50px 0px;
                    transform: translate(-150px, 0px);
                    transition: all 0.5s;
                  
                  }

                  .icons a:hover
                  {
                    transform: translate(0px, 0px);
                  }

                  .icons a i
                  {
                    margin-left: 25px;
                    background-color: white;
                    height: 30px;
                    width:30px;
                    color:black;
                    text-align: center;
                    line-height: 30px;
                    border-radius: 50%;
                    transition: all 0.5s;
                  }

                  .icons a:hover i
                  {
                    transform: rotate(360deg);
                  }
                  .icons a i.fa-facebook-f
                  {
                    color:#2C80D3;
                  }
                  .icons a i.fa-youtube
                  {
                    color:#fa0910;
                  }


                  .Facebook
                  {
                    background-color: #2C80D3;
                    color:white;
                  }

                 

                  .Instagram
                  {
                    background-color: #3f729b ;
                    color:white;
                  }
		 .hero-cont {
  			height: 800px;
  			position: relative;
  
  			text-align: center;
			}


.hero-img {
  position: relative;
  margin-top: 15px;
  background-image: url('image/as.jpg');
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  background-attachment: scroll;
}
</style>


  </head>
  <body>


    <!navigation along with slider>

    
<?php

include('header.php')

?>


	<!--------------------------banner image------------------------------------------------->
<div class="row">
             <div class=" col-sm-12">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="image/fores.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="image/Trees.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="image/abc.jpg" alt="Third slide" width="">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
          </div>
        </div>
             
         </div>


  <!--------------------------banner image------------------------------------------------->




	 
<!--------------------------------------HOMEPAGE CART------------------------------------------->

  

  <!-- Displaying Products Start -->
  <div class="container" style="background-color:#071504;">
    <div id="message"></div>
    <div class="row mt-3 pb-3  ">
      <?php
        include 'config.php';
        $stmt = $conn->prepare('SELECT * FROM product');
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()):
      ?>
      <div class="col-md-4 col-sm-6 col-lg-4 mb-2">
        <div class="card-deck mt-3">
          <div class="card p-2 border-secondary mb-2">
            <img  src="<?= $row['product_image'] ?>" class="card-img-top" height="300" >
            <div class="card-body p-1">
              <h4 class="card-title text-center text-info"><?= $row['product_name'] ?></h4>
              <h5 class="card-text text-center text-danger"><i class="fas fa-rupee-sign"></i>&nbsp;&nbsp;<?= number_format($row['product_price'],2) ?>/-</h5>

            </div>
            <div class="card-footer p-1">
              <form action="cart.php" class="form-submit">
                <div class="row p-2">
                  <div class="col-md-6 py-1 pl-4">
                    <b>Quantity : </b>
                  </div>
                  <div class="col-md-6">
                    <input type="number" class="form-control pqty" value="<?= $row['product_qty'] ?>">
                  </div>
                </div>
                <input type="hidden" class="pid" value="<?= $row['id'] ?>">
                <input type="hidden" class="pname" value="<?= $row['product_name'] ?>">
                <input type="hidden" class="pprice" value="<?= $row['product_price'] ?>">
                <input type="hidden" class="pimage" value="<?= $row['product_image'] ?>">
                <input type="hidden" class="pcode" value="<?= $row['product_code'] ?>">
                <button class="btn btn-info btn-block addItemBtn"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to
                  cart</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <?php endwhile; ?>
    </div>


  </div>
  <!-- Displaying Products End -->

  
  <script type="text/javascript">
  $(document).ready(function() {

    // Send product details in the server
    $(".addItemBtn").click(function(e) {
      e.preventDefault();
      var $form = $(this).closest(".form-submit");
      var pid = $form.find(".pid").val();
      var pname = $form.find(".pname").val();
      var pprice = $form.find(".pprice").val();
      var pimage = $form.find(".pimage").val();
      var pcode = $form.find(".pcode").val();

      var pqty = $form.find(".pqty").val();

      $.ajax({
        url: 'action.php',
        method: 'post',
        data: {
          pid: pid,
          pname: pname,
          pprice: pprice,
          pqty: pqty,
          pimage: pimage,
          pcode: pcode
        },
        success: function(response) {
          $("#message").html(response);
          window.scrollTo(0, 0);
          load_cart_item_number();
        }
      });
    });

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'action.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  </script>


<!-------------------------------------- END HOMEPAGE CART------------------------------------------->








<!----------------------------------- About us start ---------------------------------------------->

<section id="about">
<div class="bg-success " >

<h1 class="text-center text-capitalize  text-warning">SOLVING 3 BIG BURNING PROBLEMS</h1>


<div class="row ">
	<div class="col-lg-4 col-md-4 col-12 text-center">
		
    <img src="image/plant-3751683_1920.png" class="img-fluid">
     <h3  class="text-warning" style="color:#a95d1a; ">


BEST GIFT TO EXPRESS
REAL  LOVE, NO
CONFUSION IN GIFT SELECTION

     </h3>

	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center">
		<img src="image/money-4867332_1920.jpg" class="img-fluid">
        <h3 class="text-warning" style="color:#a95d1a;">
          EMPOWERING INDIAN FARMERS
GENERATING INCOME FOR INDIAN FARMERS

        </h3>

	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center">
		<img src="image/ecology-4287428_1920.jpg" class="img-fluid">
         <h3 class="text-warning" style="color:#a95d1a;">FIGHTING POLLUTION & CLIMATE CHANGE

         </h3>
	</div>


	<!--<div class=" row col-lg-12 col-md-12 col-12  bg-success">
		<h3 class="text-right ml-3">MY name is Tarun</h3>
		<h3 class="text-center">MY name is Rohit</h3>
		<h3 class="text-left">MY name is Amit</h3>
		
		
	</div>--->




</div>

<!-----image end first--->


<div class="row ">
	<div class="col-lg-4 col-md-4 col-12 text-center">
		
       <img src="image/eco-2221567_1280.jpg" class="img-fluid">

	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center text-warning " style="color:#a95d1a;">
		
        <h1 class="mt-2">About Us</h1>
        <p>hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun </p>


	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center">
        <img src="image/businessman-2875840_1920.jpg" class="img-fluid">
	</div>
</div>

<!-----image end second--->

<div class="row ">
	<div class="col-lg-4 col-md-4 col-12 text-center text-warning" style="color:#a95d1a;">
		
       <h1>Our Mission</h1>
        <p>hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun </p>

	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center text-warning">
		
        <img src="image/money-3581678_1920.jpg" class="img-fluid">


	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center text-warning" style="color:#a95d1a;">
        <h1>Our Vision</h1>
        <p>hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun</p>
	</div>
</div>

<!-----image end third-->

<div class="row ">
	<div class="col-lg-3 col-md-3 col-12 text-center text-warning">
		
       

	</div>
	<div class="col-lg-6 col-md-6 col-12 text-center text-warning">
		
        <img src="image/tree-1511608_1920.png" class="img-fluid">


	</div>
	<div class="col-lg-3 col-md-3 col-12 text-center text-warning">
        
	</div>
</div>






</div>

</section>



<!-- About us end -->

<?php

include('footer.php');



?>
        

                  
		

     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    
  </body>
</html>