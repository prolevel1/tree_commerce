<!-- <?php include('server.php') ?> -->

<!DOCTYPE html>
<html>
<head>
	<title>Login / Sign Up Form</title>
	<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> -->
	<link rel="stylesheet" href="./src/main.css">
</head>
<body>
<div class="container">
	<form class="form form-hidden" id="login" action="./" method="post">
		<h1 class="form_title">Login</h1>
		<div class="form_message form_message-error">
			<!-- <?php include('errors.php'); ?> -->
		</div>
		<div class="form_input-group">
			<input type="text" class="form_input" autofocus placeholder="username or email" name="username" required>
			<div class="form_input-error-message"></div>
		</div>
		<div class="form_input-group">
			<input type="password" class="form_input" autofocus placeholder="password" name="password" required>
			<div class="form_input-error-message"></div>
		</div>
		<button class="form_button" type="submit" name="login_user">Login</button>
		<p class="form_text">
			<a href="#" class="form_link">Forgot your password</a>
		</p>
		<p class="form_text">
			<a href="./" class="form_link" id="linkCreateAccount">Don't have an account? Register Here</a>
		</p>

	</form>
	<form class="form" id="createAccount" action="./" method="post">
		<h1 class="form_title">Join Our Army</h1>
		<div class="form_message form_message-error">
		<!-- 	<?php include('errors.php'); ?> -->
		</div>
		<div class="form_input-group">
			<input type="text" class="form_input" autofocus placeholder="Username" name="username" required>
			<div class="form_input-error-message"></div>
		</div>
		<div class="form_input-group">
			<input type="text" class="form_input" autofocus placeholder="Contact no" name="phone" required>
			<div class="form_input-error-message"></div>
		</div>
		<div class="form_input-group">
			<input type="text" class="form_input" autofocus placeholder="Email Address" name="email" required>
			<div class="form_input-error-message"></div>
		</div>
		<div class="form_input-group">
			<input type="password" class="form_input" autofocus placeholder="Password" name="password" required>
			<div class="form_input-error-message"></div>
		</div>
		<button class="form_button" type="submit" name="register_user">Sign Up</button>
		<p class="form_text">
			<a href="./" class="form_link" id="linkLogin">Already have an account? Sign in</a>
		</p>

	</form>
</div>
<!-- <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script> -->
	<script src="./src/main.js"></script>
</body>
</html>