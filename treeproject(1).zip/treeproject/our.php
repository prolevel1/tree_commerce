<!DOCTYPE html>
<html>
<head>
	<title>our army</title>

	<link rel="stylesheet" type="text/css" href="our.css">

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">




 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">---------->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
</head>
<body>

	<div>
		<p>Treesthan is working to make india greener. To reduce co2 content and increase oxygen content in the air. so our families can breathe freely.<br><br>

		Two huge supporting pillars of treesthan are<br>
		&nbsp&nbsp&nbsp1.Farmers Army.<br>
		&nbsp&nbsp&nbsp2.Treesthan Army.<br><br>

		Farmers Army works hard in the hot fields to make this plan successful. we take the orders and handover them to farmers. They grow these plants in their own fields. Take care of the tree in every harsh condition, whether it is extremely cold or red hot summer. They water them regularly and also feed fertilizers if needed.<br><br>


		The Second strong pillar which boosts this organization is the Treesthan army.  you can call them the heart of our organization. Who empowers us by their presence.<br><br>
		​
		Every single person who joins our army in, either way, whether through email subscription or following us on social media channels(we are available on each platform) is a contribution to Treesthan and a step to make India green.<br><br>

		In Earlier days there was no such way to make plantation so easy and make it throttling fast.<br><br>
		​
		But now Treesthan is ready to make it huge. we are ready to do the harder part in fields and leave the easier one on YOU. Simply join our treesthan army.<br><br>

		</p>
	</div>

	<p class="text-center text-warning m-3">Treesthan Making Plantation Digital</p>

</body>
</html>