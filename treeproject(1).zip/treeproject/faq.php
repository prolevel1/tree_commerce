<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>
  <link rel="stylesheet" href="faq.css">
</head>
<body>



  <div class="container " style="background-color: black;">
    <img src="image/img2.jpg" alt="" class="image">
    <div class="accordion-menu">
      <div class="item" id="item1">
        <a href="#item1" class="title">
          <span>What is the purpose of a Tree Preservation Order (TPOs)?</span>
          <i class="icon"></i>
        </a>
        <p class="text">
          Tree Preservation Orders are used to protect trees of a high amenity value or which have a significant impact on the environment.
        </p>
      </div>

      <div class="item" id="item2">
        <a href="#item2" class="title">
          <span>How do I find out if my tree is protected?</span>
          <i class="icon"></i>
        </a>
        <p class="text">
          Your Local Planning Authority (your local Council) will hold the information about all the protected trees in your area, so the best thing to do is to contact them in the first instance.
        </p>
      </div>

      <div class="item" id="item3">
        <a href="#item3" class="title">
          <span>How is a tree assessed as being suitable for a TPO?</span>
          <i class="icon"></i>
        </a>
        <p class="text">
          Tree’s that can be protected must first be assessed by the local authority as being an important landscape feature, offering significant benefits to the general public.
        </p>
      </div>

      <div class="item" id="item4">
        <a href="#item4" class="title">
          <span>How do I apply to carry out works on a protected tree? And how long does it take?</span>
          <i class="icon"></i>
        </a>
        <p class="text">
          Local authority planning departments provide application forms and have eight weeks from the date of receipt to make a decision.


        </p>
      </div>
    </div>
  </div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>