<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


	<nav class="navbar navbar-expand-lg navbar-light fixed-top text-warning">
      <div class="container-fluid">
         <div class="icons">
            <a href="https://www.facebook.com" target="_blank" class="Facebook">Facebook <i class="fab fa-facebook-f"></i></a>
           
            <a href="https://www.instagram.com" target="_blank" class="Instagram">Instagram <i class="fab fa-instagram"></i></a>
          </div>

          <a class="navbar-brand text-warning" ><img src="logo.jpg" alt="">How We Work</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link text-warning" href="#">Gift Tree<span class="sr-only">(current)</span></a>
            </li>
		<li class="nav-item">
              <a class="nav-link text-warning" href="#">Tree Story</a>
            </li> 
		<li class="nav-item">
              <a class="nav-link text-warning" href="#about">About Us</a>
            </li>
			<li class="nav-item">
              <a class="nav-link  text-warning" href="our.php">Our Army</a>
            </li>
			
			<li class="nav-item">
              <a class="nav-link text-warning" href="faq.php">FAQ</a>
            </li>
			
		
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-warning" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                More
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          
                <a class="dropdown-item text-warning" href="contact.php">Contact</a>
                <a class="dropdown-item text-warning" href="#">Product</a>
                <a class="dropdown-item text-warning" href="faq.php">FAQ</a>
                
              </div>
            </li>
		<li class="nav-item">
              <a class="nav-link text-warning" href="login.php">Login</a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link  text-warning" href="cart.php">Cart</a>
            </li>
          </ul>
        </div>
    </nav>


</body>
</html>