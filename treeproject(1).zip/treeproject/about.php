<!Doctype html>
<html>
<title></title>
<head>
	<meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">

   <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css' />
  

</head>

<body>
	<div class="bg-success " >

<h1 class="text-center text-capitalize text-warning">SOLVING 3 BIG BURNING PROBLEMS</h1>


<div class="row ">
	<div class="col-lg-4 col-md-4 col-12 text-center">
		
    <img src="image/plant-3751683_1920.png" class="img-fluid">
     <h3 class="text-warning">


BEST GIFT TO EXPRESS
REAL  LOVE, NO
CONFUSION IN GIFT SELECTION

     </h3>

	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center">
		<img src="image/money-4867332_1920.jpg" class="img-fluid">
        <h3 class="text-warning">
          EMPOWERING INDIAN FARMERS
GENERATING INCOME FOR INDIAN FARMERS

        </h3>

	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center">
		<img src="image/ecology-4287428_1920.jpg" class="img-fluid">
         <h3 class="text-warning">FIGHTING POLLUTION & CLIMATE CHANGE

         </h3>
	</div>


	<!--<div class=" row col-lg-12 col-md-12 col-12  bg-success">
		<h3 class="text-right ml-3">MY name is Tarun</h3>
		<h3 class="text-center">MY name is Rohit</h3>
		<h3 class="text-left">MY name is Amit</h3>
		
		
	</div>--->




</div>

<!-----image end first--->


<div class="row ">
	<div class="col-lg-4 col-md-4 col-12 text-center">
		
       <img src="image/eco-2221567_1280.jpg" class="img-fluid">

	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center text-warning">
		
        <h1 class="mt-2">About Us</h1>
        <p>hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun </p>


	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center">
        <img src="image/businessman-2875840_1920.jpg" class="img-fluid">
	</div>
</div>

<!-----image end second--->

<div class="row ">
	<div class="col-lg-4 col-md-4 col-12 text-center text-warning">
		
       <h1>Our Mission</h1>
        <p>hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun </p>

	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center text-warning">
		
        <img src="image/money-3581678_1920.jpg" class="img-fluid">


	</div>
	<div class="col-lg-4 col-md-4 col-12 text-center text-warning">
        <h1>Our Vision</h1>
        <p>hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun hello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarunhello i am tarun</p>
	</div>
</div>

<!-----image end third-->

<div class="row ">
	<div class="col-lg-3 col-md-3 col-12 text-center text-warning">
		
       

	</div>
	<div class="col-lg-6 col-md-6 col-12 text-center text-warning">
		
        <img src="image/tree-1511608_1920.png" class="img-fluid">


	</div>
	<div class="col-lg-3 col-md-3 col-12 text-center text-warning">
        
	</div>
</div>

<div class="col-lg-12 col-md-12 col-12">

          <h1 class="text-center text-warning mb-7">GIFTING TREE !!<br> WHAT'S SO SPECIALS?<br> WILL IT SOUND GOOD?</h1>

          <p class="text-warning">YES.!! Ofcourse.!!<br>

A tree is a Unique, Special Gift, which expresses your deep feelings and your care for your loved ones.
<br><br>
​

A person who has plans for the future is obviously Intelligent.<br>

and if you are gifting or planting a tree, obviously you think about your good future.<br>

Everyone feels secure in their company. It shows their Broad perspective.<br>

So, Planting is the best Gift.<br>

.<br>

.<br>

And this current scenario...OMG!!!<br>

.<br>

Nobody would have ever Imagined, we as a generation would be facing Corona Pandemic and people around us would be dying so dramatically.<br>

.<br>

If our generation continues with this same speed damaging the Nature, the time is not far,<br>

when we would be carrying oxygen cylinders on our back and wearing Airtight Gas masks.<br>

.<br>

We can't sit and wait for the vaccine.<br>

We have to take actions.<br>

 

Even if the vaccine comes,<br>

What if some other Virus respread. How Sure are we, this won't happen again..?<br>

.<br>

Applying for Insurance can only return the money, but not the person.<br>

.<br>

But we have a solution for this, NATURE (if we act now).<br>

Let Mother Nature Handle this.<br>

The only need is we support her, instead of damaging her.<br>

Those who are breathing, have to plant a tree otherwise, nature is watching us.<br><br>

​

The solution is Plant a Tree...!!<br>

" The best time to plant a tree was 20 years ago. The Second best time is now."<br>

​</p>

		     <p class="text-warning text-right text-warning">*P.S.- Note from the Founder</p>

    <dir class="row">
    	
       <p  class="col-lg-6 col-md-6 col-12 text-left text-warning mr-50" >Phone: +91-7726002837<br>

                      Email: info@treesthan.com<br>

                     Founder email id: erskm101@gmail.com</p>

<p class="col-lg-6 col-md-6 col-12 text-right text-warning ml-50">
	HELP<br>

Shipping & Returns<br>

Privacy Policy<br>

FAQ
</p>



    </dir>

<p class="text-warning text-center">reesthan - Making Plantation Digital </p>

	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>



</html>